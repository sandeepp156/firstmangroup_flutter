## 0.0.1
    
    first version

## 0.1.0

    README file fix.

## 0.1.1

    Usage arrange properly

## 0.1.2

    README fixes