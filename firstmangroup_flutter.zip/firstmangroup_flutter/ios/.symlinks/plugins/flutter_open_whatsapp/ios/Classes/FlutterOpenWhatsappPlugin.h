#import <Flutter/Flutter.h>

@interface FlutterOpenWhatsappPlugin : NSObject<FlutterPlugin>
@end
