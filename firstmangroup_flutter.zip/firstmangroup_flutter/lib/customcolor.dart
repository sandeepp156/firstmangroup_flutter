
import 'package:flutter/material.dart';

  class GlobalVariable{
    static var primary = Colors.green;
    static var primary_= Color(0xff43545);
    static var text_colors_black = Colors.black;
    static var text_colors_green = Colors.green;
    static var blue_main=Color(0xff0E2D6B);
    static var yellow_main=Color(0xffFAA61A);
    static var yellow_main_thick=Colors.deepOrangeAccent;
    static var white=Colors.white;
    static var red=Colors.red;
    static var light_green=Colors.greenAccent;
    static var grey_main=Color(0xffd3d3d3);
    static var grey_main_=Colors.grey;
    static var light_blue=Colors.blue;
    static var BASE_URL = 'firstmangroup.in';
    static var member_id = '4';
    //member_id=4
    //https://firstmangroup.in/api/
    static var GothamMedium = 'GothamMedium';
    static var Gotham = 'Gotham';
    static var GothamLight = 'GothamLight';

  }
